/*
 * main.c
 *
 *  Created on: 24-Jul-2015
 *      Author: tejas
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

long Square(long,int);


int main()
{
	int iData,iLocal = 0;
	int iFile_Pipes[2];
	char chData[20];
	char chBuffer[BUFSIZ+1];

	pid_t Child_Square;
	
	if(pipe(iFile_Pipes) == 0)
	{
		Child_Square = fork();
		switch(Child_Square)
		{
			case -1:
				fprintf(stderr,"Child process creation failed!\n");
				exit(EXIT_FAILURE);

			case 0:
				while(iLocal++ < 1000)
				{
					long lSquare = iLocal;
					int iCount = iLocal;
					Square(lSquare,iCount);
					iData = write(iFile_Pipes[1], chData, strlen(chData));
//					printf("%d.Wrote %d bytes\n",iLocal, iData);
				}
					break;

			default:
				while(iLocal != 1000)
				{
					iData = read(iFile_Pipes[0],chBuffer,BUFSIZ);
					memset(chData,0x00,sizeof(chData));
					memset(chBuffer,0x00,sizeof(chBuffer));
					printf("%d.Read: %s\n",iLocal, chBuffer);
				}
				break;
		}
	}
	exit(EXIT_SUCCESS);
}


long Square(long lVal,int iCount)
{
	if(iCount > 0)
		lVal += Square(lVal,iCount--);
	else
		return lVal;
}
