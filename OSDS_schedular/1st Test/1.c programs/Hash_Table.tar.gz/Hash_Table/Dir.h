/*
 * Dir.h
 *
 *  Created on: 17-Jul-2015
 *      Author: tejas
 */

#ifndef DIR_H_
#define DIR_H_
#include	"Hash.h"


int 		Get_Dir(char *,int);
void 		Get_File(char *, char *,Hash_Table_C_p *);

#endif /* DIR_H_ */
