/*
 * Chat_Server.c
 *
 *  Created on: 11-Aug-2015
 *      Author: tejas
 */

#include 	<stdio.h>
#include 	<unistd.h>
#include 	<string.h>
#include 	<stdlib.h>
#include	<sys/stat.h>
#include	<netinet/in.h>
#include	<sys/socket.h>
#include 	<sys/msg.h>
#include	<sys/time.h>
#include	<sys/types.h>
#include	<errno.h>


typedef struct sockaddr_in 	Socket_t;											/*	Structure is renamed for shorter name in program*/
typedef struct timeval		Time_Out_t;											/*	Structure is renamed for shorter name in program*/


struct 	Message_Queue															/*	Message queue structure*/
{
	char		chMessage_Buffer[100];
	long int	liMsg_Type;
}Parent_Child_t;



int			iServer_Sockfd;														/*	File descriptor of server socket*/
pid_t		Child_Process;														/*	Child process variable of type pid_t*/


void 		Get_User_Name(char *);
Socket_t	Connect_Socket_Server(void);


int main()
{
	char 		chUser_Name[33];
	char		chMessage[100];
	char		chTo[15];
	int			iMsg_Len;
	int			iMsg_ID;
	long int	liMsg_Type = 0;
	int			iNum_Connections = 0;
	int			iBreak_Time = 0;
	Socket_t 	Server_Address,Client_Socket;									/*	Client and Server socket structures*/;
	Time_Out_t	Connection_Accept_Time;											/*	Time out struct object for accepting connection*/
	fd_set		Accept_Fds;														/*	File descriptor of the above mentioned timeout*/
	int			iRet_Val;														/*	Return value from select() is stored in this*/
	int			iClient_Sockfd;													/*	File descriptor of client socket*/
	int			iClient_Len;													/*	Length of client socket*/


	memset(chUser_Name,0x00,sizeof(chUser_Name));
	memset(chMessage,0x00,sizeof(chMessage));
	memset(chTo,0x00,sizeof(chTo));
	
	strcpy(chTo,"To ");

	Get_User_Name(chUser_Name);

	strncpy(chMessage,chUser_Name,strlen(chUser_Name)-1);
	strcat(chMessage,": ");
	iMsg_Len = strlen(chMessage);

	Server_Address = Connect_Socket_Server();

	printf("Server is waiting\n");

//	fprintf(stderr,"%s",chMessage);

	while(1)
	{
		if(iBreak_Time == 1)													/*	If this variable is set*/
		{
			msgrcv(iMsg_ID,														/*	Receive a msg from the client for disconnection*/
				   (void *)&Parent_Child_t,
				   100,
				   liMsg_Type, 0);// IPC_NOWAIT);
			if(strcmp(Parent_Child_t.chMessage_Buffer,							/*	Check what is the received msg*/
					"Client is disconnecting\n") == 0)
			{
				memset(Parent_Child_t.chMessage_Buffer,0x00,100);				/*	Clean the msg so that it doesnt come again unneccesarly*/
				printf("%s",Parent_Child_t.chMessage_Buffer);					/*	Print the message passed by the child client*/
				iNum_Connections--;												/*	Decrease the number of connection*/
			}
			else if(strstr(Parent_Child_t.chMessage_Buffer,
					"From ") != NULL)
			{
				strcpy(chTo+3,Parent_Child_t.chMessage_Buffer+5);
				strcpy(Parent_Child_t.chMessage_Buffer,chTo);
				Parent_Child_t.liMsg_Type = 1;

				if(msgsnd(iMsg_ID,(void *)&Parent_Child_t,100,0) == -1)
				{
					perror("Error sending message");
				}
			}
			if(iNum_Connections == 0)											/*	If number of connection is found to be 0 then terminate the program*/
				break;
		}


		Connection_Accept_Time.tv_sec = 3;										/*	Time out value of 3 seconds*/
		Connection_Accept_Time.tv_usec = 0;										/*	Time out value of 3 seconds and 0 micro-seconds*/

		FD_ZERO(&Accept_Fds);													/*	Clean the file descriptor*/
		FD_SET(iServer_Sockfd, &Accept_Fds);									/*	Set the sever "who accepts the connection" to the file descriptors*/

		iRet_Val = select(100,&Accept_Fds,NULL,NULL,&Connection_Accept_Time);	/*	Set a value specified in above time out struct*/
		if(iRet_Val == -1)														/*	Error if return value is -1*/
			perror("Read time out selection occurred an error");				/*	Error msg*/
		else if(iRet_Val)
		{
			iClient_Len = sizeof(Client_Socket);								/*	Client socket size*/
			iClient_Sockfd = accept(iServer_Sockfd,								/*	Accepts the connection from a client*/
									(struct sockaddr *)&Client_Socket,
									(socklen_t *)&iClient_Len);
			printf("Client joined on port %d\n",Client_Socket.sin_port);		/*	Print the information regarding the connection established*/
			iBreak_Time = 1;													/*	Set the variable so that it will next time check whether to break or not*/
			iNum_Connections++;													/*	Increament the connection*/
		}
		else
			continue;


		iMsg_ID = msgget((key_t)1234, 0666 | IPC_CREAT);						/*	Create a message queue*/
		if (iMsg_ID == -1)
		{
			fprintf(stderr, "msgget failed with error: %d\n", errno);			/*	Error msg*/
			exit(EXIT_FAILURE);
		}

		Child_Process = fork();													/*	Create a child*/
		if(Child_Process == -1)
		{
			perror("Can not create child process");								/*	Error msg*/
		}
		else if(Child_Process == 0)
		{
			char		chBuffer[100];											/*	Read buffer for client*/
			char		chPort[10];
			char		chWait_Turn[15];
			char 		chPass[15];
			Time_Out_t	Scan_Input,Socket_Time_Out;								/*	Time out struct object for accepting connection*/
			fd_set		Terminal_Fds,Socket_Fds;								/*	File descriptor of the above mentioned timeout*/

			if(close(iServer_Sockfd) == -1)										/*	Close the duplicate file descriptor*/
				perror("Child can not proceed");								/*	Error msg*/

			memset(chPort,0x00,sizeof(chPort));
			memset(chWait_Turn,0x00,sizeof(chWait_Turn));
			memset(chPass,0x00,sizeof(chPass));

			strcpy(chWait_Turn,"To ");
			strcpy(chPass,"From ");
			sprintf(chPort,"%d",Client_Socket.sin_port);
			strcat(chWait_Turn,chPort);
			strcat(chWait_Turn,"\n");
			strcat(chPass,chPort);
			strcat(chPass,"\n");

			while(1)
			{
				sleep(3);
				msgrcv(iMsg_ID,&Parent_Child_t,100,liMsg_Type,IPC_NOWAIT);
				if(strcmp(Parent_Child_t.chMessage_Buffer,chWait_Turn) == 0)
				{
					memset(Parent_Child_t.chMessage_Buffer,0x00,100);
					FD_ZERO(&Terminal_Fds);											/*	Clean the file descriptor*/
					FD_SET(0, &Terminal_Fds);										/*	Set the sever "who accepts the connection" to the file descriptors*/

					Scan_Input.tv_sec = (1 * iClient_Sockfd);
					Scan_Input.tv_usec = 0;

					iRet_Val = select(1,&Terminal_Fds,NULL,NULL,&Scan_Input);		/*	Set a value specified in above time out struct*/
					if(iRet_Val == -1)
						perror("Error in select()");
					else if(iRet_Val)
					{
						read(0,chBuffer,90);
						memset(chMessage+iMsg_Len,0x00,sizeof(chMessage)-iMsg_Len);
						strcpy(chMessage+iMsg_Len,chBuffer);
						write(iClient_Sockfd,chMessage,strlen(chMessage));
						memset(chBuffer,0x00,sizeof(chBuffer));
					}
				}

				FD_ZERO(&Socket_Fds);											/*	Clean the file descriptor*/
				FD_SET(iClient_Sockfd, &Socket_Fds);							/*	Set the sever "who accepts the connection" to the file descriptors*/

				Socket_Time_Out.tv_sec = (1 * iClient_Sockfd);
				Socket_Time_Out.tv_usec = 0;

				iRet_Val = select(20,&Socket_Fds,NULL,NULL,&Socket_Time_Out);	/*	Set a value specified in above time out struct*/
				if(iRet_Val == -1)
					perror("Error in select()");
				else if(iRet_Val)
				{
					memset(chBuffer,0x00,sizeof(chBuffer));
					read(iClient_Sockfd,chBuffer,sizeof(chBuffer));
					if(strstr(chBuffer,"exit\n") != NULL)
						break;
//					printf("MSG from client on port %d\n",Client_Socket.sin_port);
					printf("%s",chBuffer);
					memset(chBuffer,0x00,sizeof(chBuffer));

					strcpy(Parent_Child_t.chMessage_Buffer,chPass);				/*	Copy the data in to Message queue structure*/
					Parent_Child_t.liMsg_Type = 1;								/*	Message is to be send*/

//					printf("\n%s",Parent_Child_t.chMessage_Buffer);			/*	Print the message*/

					if (msgsnd(iMsg_ID, (void *)&Parent_Child_t, 100, 0) == -1)	/*	Send the message*/
					{
						fprintf(stderr, "msgsnd failed\n");						/*	Error msg*/
						exit(EXIT_FAILURE);
					}
//					printf("Msg sending function called\n");
				}
			}

			printf("User is leaving.\n");
			strcpy(Parent_Child_t.chMessage_Buffer								/*	Copy the data in to Message queue structure*/
					,"Client is disconnecting\n");
			Parent_Child_t.liMsg_Type = 1;										/*	Message is to be send*/

			printf("%s",Parent_Child_t.chMessage_Buffer);						/*	Print the message*/

			if (msgsnd(iMsg_ID, (void *)&Parent_Child_t, 100, 0) == -1)			/*	Send the message*/
			{
				fprintf(stderr, "msgsnd failed\n");								/*	Error msg*/
				exit(EXIT_FAILURE);
			}

			if(close(iClient_Sockfd) == -1)										/*	Close client descriptors*/
				fprintf(stderr,
						"Error in closing the %d client socket",
						iClient_Sockfd);
			printf("Child Terminated...\n");									/*	Child is terminated*/
			exit(EXIT_SUCCESS);													/*	Exit with success*/
		}
	}

	if(close(iServer_Sockfd) == -1)
	{
		perror("Error in closing the server socket.");
	}

	return 0;
}



void Get_User_Name(char *chTemp)
{
	FILE	*fptrRead_User_Name;
	int		iLocal;

	fptrRead_User_Name = popen("whoami","r");									/*	Opens a pipe for reading*/
	if(fptrRead_User_Name != NULL)
	{
		iLocal = fread(chTemp,sizeof(char),100,fptrRead_User_Name);				/*	Read the pipe*/
		if(iLocal == 0)
			perror("Error in reading opened pipe\n");							/*	Error message*/
	}
	if(pclose(fptrRead_User_Name) == -1)										/*	Close the pipe after reading is done*/
	{
		perror("Error in closing the opened pipe.\n"							/*	Error message*/
				"This will terminate the program.\n");
		exit(EXIT_FAILURE);														/*	Program should not continue as it will not perform																					as it should be*/
	}
}


/*
 * Function name	:	Connect_Socket_Server
 *
 * Description		:	use this function to Create and connect a socket server
 *
 * Parameters		:	Socket_t Temp -> This is an object to the type
 * 										 sockaddr_in
 *
 * Returns			:	None
 */
Socket_t Connect_Socket_Server(void)
{
	int 		iServer_Len;													/*	Length of server socket*/
	Socket_t	Temp;

	iServer_Sockfd = socket(AF_INET, SOCK_STREAM, 0);							/*	Creates a socket for server*/
	if(iServer_Sockfd == -1)
	{
		fprintf(stderr,"Socket creation failed in server. "						/*	Error in creating a socket*/
				"Program will terminate.\n");
		exit(EXIT_FAILURE);														/*	Exit the program as no other function can work*/
	}


	Temp.sin_family = AF_INET;											/*	Setting values in structure*/
	Temp.sin_addr.s_addr = htonl(INADDR_ANY);							/*	Accepts any IP*/
	Temp.sin_port = htons(9734);										/*	Accepts connection on this port*/
	iServer_Len = sizeof(Temp);

	bind(iServer_Sockfd, (struct sockaddr *)&Temp, iServer_Len);		/*	Bind the socket_fd to Server_Socker*/

	listen(iServer_Sockfd, 5);													/*	Listen the clients maximum of 5*/

	return Temp;
}
