/*
 * Client.c
 *
 *  Created on: 04-Aug-2015
 *      Author: tejas
 */

#include 	<stdio.h>
#include 	<unistd.h>
#include 	<string.h>
#include 	<stdlib.h>
#include	<netinet/in.h>
#include	<arpa/inet.h>
#include	<sys/socket.h>
#include	<sys/types.h>
#include	<time.h>


typedef struct sockaddr_in Socekt_Address_t;

int main()
{
	int 				iSockfd;
	int 				iLen;
	int 				iResult;
	double				dTotal;
	Socekt_Address_t 	Client_Address;
	char 				chBuffer[1024];
	time_t				Start_Time,End_Time,Gap_Time;

	memset(chBuffer,0x00,sizeof(chBuffer));

	iSockfd = socket(AF_INET, SOCK_STREAM, 0);

	
	Client_Address.sin_family = AF_INET;
	Client_Address.sin_addr.s_addr = inet_addr("127.0.0.1");
	Client_Address.sin_port = htons(9734);
	iLen = sizeof(Client_Address);

	iResult = connect(iSockfd, (struct sockaddr *)&Client_Address, iLen);
	if(iResult == -1)
	{
		perror("Error in connecting to the server.\n"
				"This will terminate the program.\n");
		close(iSockfd);
		exit(EXIT_FAILURE);
	}
	while(1)
	{
		if(fgets(chBuffer,sizeof(chBuffer),stdin) == NULL)
		{
			fprintf(stderr,"Reading error\n");
		}

		Start_Time = clock();
		write(iSockfd,chBuffer,sizeof(chBuffer));
		End_Time = clock();
		dTotal = (double)(End_Time - Start_Time)/CLOCKS_PER_SEC;

		Gap_Time = clock();

		Start_Time = clock();

		dTotal += (double)(Start_Time - Gap_Time)/CLOCKS_PER_SEC;

		read(iSockfd,chBuffer,sizeof(chBuffer));
		End_Time = time(NULL);
		dTotal += (double)(End_Time - Start_Time)/CLOCKS_PER_SEC;

		printf("Message from the server is: %s\n"
				"Processing time is: %f\n",chBuffer,dTotal);

		if(strncmp(chBuffer,"quit",4) == 0)
			break;
	}
	if(close(iSockfd) == -1)
		perror("Error in closing socket\n");
	exit(EXIT_SUCCESS);
}
