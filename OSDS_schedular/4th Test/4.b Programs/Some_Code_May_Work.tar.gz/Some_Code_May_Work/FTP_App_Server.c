/*
 * FTP_App_Server.c
 *
 *  Created on: 05-Aug-2015
 *      Author: tejas
 */

#include 	<stdio.h>
#include 	<unistd.h>
#include 	<string.h>
#include 	<stdlib.h>
#include 	<dirent.h>
#include	<sys/stat.h>
#include	<netinet/in.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<time.h>
//#include	<signal.h>
#include	"Dir.h"


typedef struct sockaddr_in 	Socket_t;											/*	structure is renamed for shorter name in program*/
typedef struct timeval		Time_Out_t;

int 		iStore;																/*	Determines how many files to read MAX 20 can be read*/
char 		chFiles[20][70];													/*	List of files scanned from directory is stored in this*/
char		chUser_Name[33];													/*	User name is stored in this*/
char 		chFull_Path[150];													/*	Path to scan/ open the directory*/
char		chStore_File_Path[2][70];											/*	Path to store the file information*/
FILE		*fptrRead_User_Name;												/*	Reads the username by pipe*/
FILE		*fptrFile_Info;														/*	Access the File_Info.txt*/
FILE		*fptrFiles;															/*	Access the File_List.txt*/
int			iStr_Len;															/*	Checks for the length of the chFull_Path*/
char		chOption[15];
char		*chptrTemp_Buf = NULL;
int			iClient_Sockfd;
int			iServer_Sockfd;
int			iNum_To_Read;
char		chBuffer[2048];
Socket_t 	Server_Socket, Client_Socket;										/*	Client and Server socket structures*/
fd_set		Read_Fds,Test_Fds;
Time_Out_t	Time_Out_Client;

void 	Create_List_Of_Files(void);
void 	Option_1_Response(void);
void 	Option_2_Response(void);
void 	Option_3_Response(void);
void 	Get_User_Name(void);
void	Close_All(void);
void 	Connect_Socket_Server(void);

int main()
{
	int			iClient_Len;
	int			iFd;

	memset(chBuffer,0x00,sizeof(chBuffer));
	memset(chOption,0x00,sizeof(chOption));

	printf("In this program TCP sockets are used as in TCP,\n"
			"it is possible to set time out for connected  sockets and\n"
			"multiple clients can get connected.\n"
			"Press any key to continue...\n");
	getchar();

	Get_User_Name();

	Create_List_Of_Files();														/*	Creates a list of files*/

	Connect_Socket_Server();


	Test_Fds = Read_Fds;

	printf("Server is waiting...\n");

	int iResult = select(FD_SETSIZE,&Test_Fds,NULL,NULL,&Time_Out_Client);

	if(iResult < 1)
	{
		perror("FTP_SERVER");
		exit(EXIT_FAILURE);
	}

	for(iFd = 0; iFd < FD_SETSIZE; iFd++)
	{
		if(FD_ISSET(iFd,&Test_Fds))
		{
			if(iFd == iServer_Sockfd)
			{
				iClient_Len = sizeof(Client_Socket);
				iClient_Sockfd = accept(iServer_Sockfd,
										(struct sockaddr *)&Client_Socket,
										(socklen_t *)&iClient_Len);
				FD_SET(iClient_Sockfd,&Read_Fds);
				printf("Adding client on fd %d\n",iClient_Sockfd);
			}
		}
	}

//	iClient_Len = sizeof(Client_Socket);
//	iClient_Sockfd = accept(iServer_Sockfd,
//							(struct sockaddr *)&Client_Socket,
//							(socklen_t *)&iClient_Len);

	read(iClient_Sockfd, chOption, sizeof(chOption));

	while(1)
	{
		Option_1_Response();
		Option_2_Response();
		Option_3_Response();
		if(strncmp(chOption,"4\n",2) == 0)
		{
			memset(chOption,0x00,sizeof(chOption));
			fprintf(stderr,"Quiting\n");
			break;
		}
		else
		{
			write(iClient_Sockfd,
					"Please provide a correct input\n",
					strlen("Please provide a correct input\n"));
		}
		read(iClient_Sockfd, chOption, sizeof(chOption));

	}

	Close_All();
	printf("Terminated...\n");
	return 0;
}


/*
 * Function name	:	Create_List_Of_Files
 *
 * Description		:	use this function to Create a file list and info list
 * 						in a text file. This files will be created on the
 * 						desktop. File names are File_List.txt and File_Info.txt
 * 						Please do not delete this file from the desktop
 * 						this will be used till the program ends
 *
 * Parameters		:	None
 *
 * Returns			:	None
 */
void Create_List_Of_Files(void)
{
	struct 	stat 	Status_of_File;												/*	Structure for scanning files information*/
	int 			iLength;													/*	Get the file name length*/
	char 			chDate[30];													/*	Convert the raw information to Readable date and time*/
	float 			fSize;														/*	Size of the file*/
	int				iLocal;														/*	Local variable*/

	strcat(chStore_File_Path[0],"/Desktop/File_Info.txt");						/*	File path to open*/
	fptrFile_Info = fopen(chStore_File_Path[0],"w+");							/*	Open a file*/
	if(fptrFile_Info == NULL)
	{
		perror("Error in creating file info list.\n"							/*	Error message*/
				"This will terminate the program");
		exit(EXIT_FAILURE);														/*	Program should terminate otherwise results may be worse*/
	}

	strcat(chStore_File_Path[1],"/Desktop/File_List.txt");						/*	File path to open*/
	fptrFiles = fopen(chStore_File_Path[1],"w+");								/*	Open a file*/
	if(fptrFiles == NULL)
	{
		perror("Error in creating file list.\n"									/*	Error message*/
				"This will terminate the program");
		exit(EXIT_FAILURE);														/*	Program should terminate otherwise results may be worse*/
	}


	for(iLocal=0;iLocal<iStore;iLocal++)
	{
		fprintf(fptrFiles,"%d. %s",iLocal+1,chFiles[iLocal]);					/*	Write the data to the file*/

		iLength = strlen(chFiles[iLocal]);										/*	Delete a \n character form the file name*/
		chFiles[iLocal][iLength-1] = '\0';

		strcpy(chFull_Path+iStr_Len, chFiles[iLocal]);							/*	Convert a file name to its full path*/

		if (stat(chFull_Path, &Status_of_File))									/*	Get the file details*/
			perror(chFiles[iLocal]);											/*	Error message*/
		else
		{
			fSize = (float)Status_of_File.st_size;								/*	Convert a file size in KB*/
			fSize /= (1000);
			strftime(chDate, 21, "%d-%m-%y %r"									/*	Convert a raw data in readable format*/
					, localtime(&(Status_of_File.st_mtime)));
			fprintf(fptrFile_Info,"%d.%s is Last Modified on: %s "				/*	Print the data in opened file*/
								  ", File size is: %.1f KB\n\n",
								  iLocal+1,
								  chFiles[iLocal],
								  chDate, fSize);
		}
	}
}


/*
 * Function name	:	Option_1_Response
 *
 * Description		:	use this function to Responde the client if the the option 1
 * 						was chosen by client
 *
 * Parameters		:	None
 *
 * Returns			:	None
 */
void Option_1_Response(void)
{
	if(strncmp(chOption,"1\n",2) == 0)
	{
		memset(chOption,0x00,sizeof(chOption));
		iNum_To_Read = ftell(fptrFiles);
		if(fseek(fptrFiles, 0L, SEEK_SET) == -1)							/*	Rewind the file pointer*/
			perror("Error in rewinding the file to read\n");				/*	Error message*/

		sleep(1);
		sprintf(chOption,"%d",iNum_To_Read);
		write(iClient_Sockfd,chOption,strlen(chOption));

		chptrTemp_Buf = (char *)malloc(iNum_To_Read*sizeof(char));
		if(chptrTemp_Buf == NULL)
			perror("Error in allocating memory\n");

		fread(chptrTemp_Buf,sizeof(char),iNum_To_Read,fptrFiles);			/*	Display the files as it is*/
		sleep(3);
		write(iClient_Sockfd,chptrTemp_Buf,iNum_To_Read);
		free(chptrTemp_Buf);
	}
}



/*
 * Function name	:	Option_2_Response
 *
 * Description		:	use this function to Responde the client if the the option 2
 * 						was chosen by client
 *
 * Parameters		:	None
 *
 * Returns			:	None
 */
void Option_2_Response(void)
{
	if(strncmp(chOption,"2\n",2) == 0)
	{
		memset(chOption,0x00,sizeof(chOption));
		iNum_To_Read = ftell(fptrFile_Info);
		if(fseek(fptrFile_Info, 0L, SEEK_SET) == -1)						/*	Rewind the file pointer*/
			perror("Error in rewinding the file to read\n");				/*	Error Message*/

		sleep(1);
		sprintf(chOption,"%d",iNum_To_Read);
		write(iClient_Sockfd,chOption,strlen(chOption));

		chptrTemp_Buf = (char *)malloc(iNum_To_Read*sizeof(char));
		if(chptrTemp_Buf == NULL)
			perror("Error in allocating memory\n");

		fread(chptrTemp_Buf,sizeof(char),iNum_To_Read,fptrFile_Info);		/*	Display the files as it is*/
		sleep(3);
		write(iClient_Sockfd,chptrTemp_Buf,iNum_To_Read);
		free(chptrTemp_Buf);
	}
}



/*
 * Function name	:	Option_3_Response
 *
 * Description		:	use this function to Responde the client if the the option 3
 * 						was chosen by client. This function reads the file to transfer
 * 						to client and send it afterwards.
 *
 * Parameters		:	None
 *
 * Returns			:	None
 */
void Option_3_Response(void)
{
	int 	iLocal;
	int 	iLength;														/*	Get the file name length*/
	FILE	*fptrSend = NULL;

	if(strncmp(chOption,"3\n",2) == 0)
	{
		memset(chOption,0x00,sizeof(chOption));
		memset(chBuffer,0x00,sizeof(chBuffer));

		read(iClient_Sockfd, chBuffer, sizeof(chBuffer));
		iLength = strlen(chBuffer);
		chBuffer[iLength -1] = '\0';

		for(iLocal = 0; iLocal < iStore ;iLocal++)
			if(strcmp(chBuffer,chFiles[iLocal]) == 0)
				break;
		strcpy(chFull_Path+iStr_Len, chFiles[iLocal]);						/*	Convert a file name to its full path*/

		fptrSend = fopen(chFull_Path,"r");

		fseek(fptrSend, 0L, SEEK_END);
		iNum_To_Read = ftell(fptrSend);
		if(fseek(fptrSend, 0L, SEEK_SET) == -1)								/*	Rewind the file pointer*/
			perror("Error in rewinding the file to read\n");				/*	Error Message*/

		sleep(1);
		sprintf(chOption,"%d",iNum_To_Read);
		write(iClient_Sockfd,chOption,strlen(chOption));
//		memset(chOption,0x00, sizeof(chOption));

		chptrTemp_Buf = (char *)malloc(iNum_To_Read*sizeof(char));
		if(chptrTemp_Buf == NULL)
			perror("Error in allocating memory\n");

		fread(chptrTemp_Buf,sizeof(char),iNum_To_Read,fptrSend);		/*	Display the files as it is*/
		sleep(3);
		write(iClient_Sockfd,chptrTemp_Buf,iNum_To_Read);

		free(chptrTemp_Buf);
		fclose(fptrSend);
	}
}



/*
 * Function name	:	Get_User_Name
 *
 * Description		:	use this function to Scan the user name and set the scanning
 * 						path for files to downloads of the particular user.
 *
 * Parameters		:	None
 *
 * Returns			:	None
 */
void Get_User_Name(void)
{
	char		*chPtr;															/*	Temp pointer to scan for required data*/
	int			iLocal;
	char		chTemp[100];													/*	Temp variable to store the pipe information*/
	int			iSuccess;														/*	Directory scanning is successful or not*/


	fptrRead_User_Name = popen("uname -a","r");									/*	Opens a pipe for reading*/
	if(fptrRead_User_Name != NULL)
	{
		iLocal = fread(chTemp,sizeof(char),100,fptrRead_User_Name);				/*	Read the pipe*/
		if(iLocal == 0)
			perror("Error in reading opened pipe\n");							/*	Error message*/
	}
	if(pclose(fptrRead_User_Name) == -1)										/*	Close the pipe after reading is done*/
	{
		perror("Error in closing the opened pipe.\n"							/*	Error message*/
				"This will terminate the program.\n");
		exit(EXIT_FAILURE);														/*	Program should not continue as it will not perform
																					as it should be*/
	}

	chPtr = strstr(chTemp,"Linux");												/*	Get the user name from the pipe output*/
	if(chPtr!= NULL)
	{
		chPtr = chPtr+6;
		strncpy(chUser_Name,chPtr,35);											/*	Copy the user name*/
		chPtr = chUser_Name;
		if(strtok(chPtr," ") == NULL)
		{
			fprintf(stderr,"Error in acquiring the username");					/*	Error message*/
		}
	}

	strcpy(chFull_Path,"/home/");												/*	String formation for Static directory scanning*/
	strcat(chFull_Path,chUser_Name);											/*	Add the user name*/
	strcpy(chStore_File_Path[0],chFull_Path);									/*	Files to be stored path*/
	strcpy(chStore_File_Path[1],chFull_Path);									/*	Files to be stored path*/
	strcat(chFull_Path,"/Downloads/");											/*	Path to scan*/

	iStr_Len = strlen(chFull_Path);												/*	String length of path*/

	iSuccess = Get_Dir(chFull_Path,0);											/*	Checks if directory scanning is successful or not*/
	if(iSuccess == 0)
	{
		printf("Please provide a directory for scan/n");						/*	Error message*/
	}

}



/*
 * Function name	:	Close_All
 *
 * Description		:	use this function to Close all the open file descriptor
 *
 * Parameters		:	None
 *
 * Returns			:	None
 */
void Close_All(void)
{
	if(close(iClient_Sockfd) == -1)
		perror("Error closing the socket");

	if(close(iServer_Sockfd) == -1)
		perror("Error closing the socket");

	if(fclose(fptrFile_Info) != 0)												/*	Close the file opened earlier*/
		perror("Error in closing file info list\n");							/*	Error message*/

	if(fclose(fptrFiles) != 0)													/*	Close the file opened earlier*/
		perror("Error in closing file list\n");									/*	Error message*/
}


/*
 * Function name	:	Connect_Socket_Server
 *
 * Description		:	use this function to Create and connect a socket server
 *
 * Parameters		:	None
 *
 * Returns			:	None
 */
void Connect_Socket_Server(void)
{
	int 		iServer_Len;

	iServer_Sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(iServer_Sockfd == -1)
	{
		fprintf(stderr,"Socket creation failed in server. Program will terminate.\n");
		exit(EXIT_FAILURE);
	}


	Server_Socket.sin_family = AF_INET;
	Server_Socket.sin_addr.s_addr = htonl(INADDR_ANY);
	Server_Socket.sin_port = htons(9734);
	iServer_Len = sizeof(Server_Socket);

	bind(iServer_Sockfd, (struct sockaddr *)&Server_Socket, iServer_Len);

	listen(iServer_Sockfd, 5);

	Time_Out_Client.tv_sec = 120;
	Time_Out_Client.tv_usec = 0;
	FD_ZERO(&Read_Fds);
	FD_SET(iServer_Sockfd,&Read_Fds);

//	signal(SIGCHLD, SIG_IGN);

}
